import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'counter',
  templateUrl: './counter.component.html',
  styles: [
  ]
})
export class CounterComponent implements OnInit {
  @Input() interval: number;
  @Output() onMax: EventEmitter<boolean>;

  flag: boolean;
  count: number;
  clickCount: number;

  constructor() {
    this.interval = 1;
    this.onMax = new EventEmitter<boolean>();
    this.flag = false;
    this.count = 0;
    this.clickCount = 0;
  }

  ngOnInit(): void {
    // this.reset();
  }

  manageClickCount() {
    this.clickCount += 1;
    if (this.clickCount > 9) {
      this.flag = true;
      this.onMax.emit(this.flag);
    }
  }

  inc() {
    // if (this.count)
    this.manageClickCount();
    this.count += this.interval;
  }

  dec() {
    // if (this.count)
    this.manageClickCount();
    this.count -= this.interval;
  }

  reset() {
    this.count = 0;
    this.clickCount = 0;
    this.flag = false;
    this.onMax.emit(this.flag);
  }
}
