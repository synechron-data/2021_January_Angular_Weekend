import { Component } from '@angular/core';
import { concat, empty, Observable, Observer, of, Subject } from 'rxjs';
import { delay, filter, map, reduce, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  subject?: Subject<number>;
  observable?: Observable<number>;

  constructor() {
    // this.getObservable().subscribe((data) => {
    //   console.log(`Observable Output - ${data}`);
    // }, (err) => {
    //   console.log(`Observable Error - ${err}`);
    // })

    // this.getPromise().then((data) => {
    //   console.log(`Promise Output - ${data}`);
    // }, (err) => {
    //   console.log(`Promise Error - ${err}`);
    // });

    // ---------------------------------------------------

    // this.getObservable().subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.getObservable().subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    // // ---------------------------------------------------
    // this.subject = this.getSubject();

    // this.subject.subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.subject.subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    // ---------------------------------------------------
    //  this.observable = this.getSubjectAsObservable();

    //  this.observable.subscribe((data) => {
    //    console.log(`Subscriber 1, Output - ${data}`);
    //  });

    //  this.observable.subscribe((data) => {
    //    console.log(`Subscriber 2, Output - ${data}`);
    //  });

    // --------------------------------------------------- Operators & Methods
    // concat(
    //   this.delayedMessage('Get Ready'),
    //   this.delayedMessage(5),
    //   this.delayedMessage(4),
    //   this.delayedMessage(3),
    //   this.delayedMessage(4),
    //   this.delayedMessage(1),
    //   this.delayedMessage('Go Now'),
    // ).subscribe((message: any) => console.log(message));

    // concat(
    //   of(10, 20, 30),
    //   of(40, 50, 60),
    // ).subscribe((message: any) => console.log(message));

    let numObservable = of(10, 20, 30, 40, 53, 60, 75, 81);
    // numObservable.subscribe(n => console.log(n));

    let evenObservable = numObservable.pipe(
      filter(n => n % 2 == 0),
      map(n => n * 10),
      reduce((acc, n) => acc + n)
    );

    evenObservable.subscribe(n => console.log(n));
  }

  delayedMessage(message: any, delayTime = 1000) {
    return empty().pipe(startWith(message), delay(delayTime));
  }

  getSubjectAsObservable(): Observable<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s.asObservable();
  }

  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s;
  }

  getObservable(): Observable<number> {
    return Observable.create((ob: Observer<number>) => {
      setInterval(function () {
        // console.log("Observable - Set Interval Executed....");
        ob.next(Math.random());
      }, 2000);
    });
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      setInterval(function () {
        // console.log("Promise - Set Interval Executed....");
        resolve(Math.random());
      }, 2000);
    });
  }
}
