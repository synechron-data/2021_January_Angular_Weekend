import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'async-observable',
  template: `
    <h2 class="text-info">With Observables</h2>
    <h2>Result: {{observableData}}</h2>
    <h2>Observable: {{observableInstance | async | percent}}</h2>
  `
})
export class AsyncObservableComponent implements OnInit, OnDestroy {
  observableData?: number;
  observableInstance?: Observable<number>;

  sub?: Subscription;

  constructor() { }

  ngOnInit(): void {
    this.sub = this.getObservable().subscribe(n => this.observableData = n);
    this.observableInstance = this.getObservable();
  }

  getObservable(): Observable<number> {
    return interval(2000).pipe(map(o => Math.random()));
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }
}
