import { Component, ContentChild, EventEmitter, HostBinding, Input, OnInit, Output } from '@angular/core';
import { InputRefDirective } from 'src/app/directives/input-ref.directive';

@Component({
  selector: 'bi-content-input',
  templateUrl: './bi-content-input.component.html',
  styleUrls: ['./bi-content-input.component.css']
})
export class BiContentInputComponent {
  @Input() icon?: string;

  @ContentChild(InputRefDirective)
  input?: InputRefDirective;

  get classes() {
    const cssClasses: any = {
      bi: true
    };
    cssClasses['bi-' + this.icon] = true;
    return cssClasses;
  }

  constructor() { }

  @HostBinding('class.focus')
  get focus() {
    return this.input ? this.input.focus : false;
  }
}
