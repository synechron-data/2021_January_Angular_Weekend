import { Component, OnInit } from '@angular/core';
import { Author } from 'src/app/models/author.interface';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html'
})

export class RootComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }

    onNewValue(val: any) {
        console.log(val);
    }
}