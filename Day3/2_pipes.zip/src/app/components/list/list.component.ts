import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styles: [
  ]
})
export class ListComponent implements OnInit {
  @Input() personList: Array<string>;
  selected: string;
  by: string;

  constructor() {
    this.personList = [];
    this.selected = "";
    this.by = "";
  }

  ngOnInit(): void {
  }

  select(pname: string, e: Event) {
    this.selected = pname;
    e.preventDefault();
  }
}
