import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from '../models/post.interface';
import { catchError, delay, retry } from "rxjs/operators";
import { Observable, throwError } from 'rxjs';

// 'root' : The application-level injector in most apps.
// 'platform' : A special singleton platform injector shared by all applications on the page.
// 'any' : Provides a unique instance in each lazy loaded module 
// while all eagerly loaded modules share one instance.

@Injectable({
  providedIn: 'root'
})
export class PostService {
  private url: string;

  constructor(private _httpClient: HttpClient) {
    this.url = "https://jsonplaceholder.typicode.com/posts";
  }

  // getPosts() {
  //   return this._httpClient.get<Array<Post>>(this.url);
  // }

  getPosts() {
    return this._httpClient.get<Array<Post>>(this.url).pipe(
      delay(3000),
      retry(3),
      catchError(this._handleError('getPosts', []))
    );
  }

  insertPost(post:Post) {
    return this._httpClient.post<Post>(this.url, post).pipe(
      delay(3000),
      retry(3),
      catchError(this._handleError('insertPost', post))
    );
  }

  deletePost(id:number) {
    var deleteUrl = `${this.url}/${id}`;

    return this._httpClient.delete(deleteUrl).pipe(
      delay(3000),
      retry(3),
      catchError(this._handleError('deleteUrl'))
    );
  }

  private _handleError<T>(operation = "operation", result?: T) {
    return (err: HttpErrorResponse): Observable<T> => {
      // Error Logging
      console.log(`${operation} failed: ${err.message}`);
      return throwError('Connection Error, please try again later....');
    }
  }
}
