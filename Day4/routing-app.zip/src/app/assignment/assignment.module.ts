import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AssignRootComponent } from './components/assign-root/assign-root.component';
import { AssignmentService } from './services/assignment.service';
import { HttpClientModule } from '@angular/common/http';
import { AssignAddEditComponent } from './components/assign-add-edit/assign-add-edit.component';
import { PubSubService } from './services/pub-sub.service';

@NgModule({
  declarations: [AssignRootComponent, AssignAddEditComponent],
  imports: [
    CommonModule,
    RouterModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  exports: [AssignRootComponent, AssignAddEditComponent],
  providers: [AssignmentService, PubSubService]
})
export class AssignmentModule { }
