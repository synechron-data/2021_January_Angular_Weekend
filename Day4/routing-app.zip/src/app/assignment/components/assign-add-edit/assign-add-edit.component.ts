import { Component, HostBinding, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { slideInOutAnimation } from 'src/app/animations/slideInOutAnimation';
import { Product } from 'src/app/models/product.model';
import { AssignmentService } from '../../services/assignment.service';
import { PubSubService } from '../../services/pub-sub.service';

@Component({
  selector: 'assign-add-edit',
  templateUrl: './assign-add-edit.component.html',
  animations: [slideInOutAnimation]
})
export class AssignAddEditComponent implements OnInit {
  @HostBinding('@slideInOutAnimation') slideInOutAnimation = true;

  title?: string;
  productFormGroup: FormGroup;
  saving = false;

  pstatus = [
    { key: 'Select Status', value: '' },
    { key: 'Available', value: 'Available' },
    { key: 'Not Available', value: 'Not Available' }
  ];

  get f() { return this.productFormGroup.controls; }

  constructor(private frmBuilder: FormBuilder, private route: ActivatedRoute, private router: Router,
    private assignmentService: AssignmentService, private puSubService: PubSubService) {
    this.productFormGroup = this.frmBuilder.group({
      id: [0, Validators.required],
      name: ["", Validators.required],
      description: ["", Validators.required],
      status: ["", Validators.required]
    });
  }

  ngOnInit(): void {
    this.title = 'Add Product';

    const productId = Number(this.route.snapshot.params['id']);

    if (productId) {
      this.title = 'Edit Product';
      this.assignmentService.getProduct(productId).subscribe(p => this.productFormGroup.patchValue(p));
    }
  }

  saveProduct() {
    if (this.productFormGroup.valid) {
      let product: Product = this.productFormGroup?.value;
      const action = product.id !== 0 ? 'updateProduct' : 'createProduct';
      this.assignmentService[action](product).subscribe(() => {
        this.router.navigate(['assign']);
        this.puSubService.publish('products-updated');
      });
    } else {
      this.productFormGroup.markAllAsTouched();
    }
  }
}
