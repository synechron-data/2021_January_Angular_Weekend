import { AfterViewInit, Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { fadeInAnimation } from 'src/app/animations/fadeInAnimation';
import { Product } from 'src/app/models/product.model';
import { AssignmentService } from '../../services/assignment.service';
import { PubSubService } from '../../services/pub-sub.service';

declare var $: any;

@Component({
  selector: 'assign-root',
  templateUrl: './assign-root.component.html',
  styleUrls: ['./assign-root.component.css'],
  animations: [fadeInAnimation],
  // host: { '[@fadeInAnimation]': '' }     // Deprecated
})
export class AssignRootComponent implements OnInit, OnDestroy, AfterViewInit {
  @HostBinding('@fadeInAnimation') fadeInAnimation = true;
  @HostBinding('style.display') display = 'block';

  products?: Array<Product>;
  message?: string;
  gap_sub?: Subscription;

  constructor(private assignmentService: AssignmentService, private pubSubService: PubSubService) { }
  
  ngAfterViewInit(): void {
    $('body').tooltip({
      selector: '.tla'
    });
  }

  ngOnInit(): void {
    this.pubSubService.on('products-updated').subscribe(_ => this.loadProducts());
    this.loadProducts();
  }

  loadProducts() {
    this.gap_sub = this.assignmentService.getAllProducts().subscribe(resData => {
      this.products = resData;
      this.message = "";
    }, (err: string) => {
      this.message = err;
    });
  }

  deleteProduct(id: number) {
    this.assignmentService.deleteProduct(id).subscribe(_ => {
      this.products = this.products?.filter(p => p.id !== id);
    });
  }

  ngOnDestroy(): void {
    this.gap_sub?.unsubscribe();
  }
}
