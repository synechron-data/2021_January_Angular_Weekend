import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Product } from 'src/app/models/product.model';

@Injectable()
export class AssignmentService {
  private url: string;

  constructor(private httpClient: HttpClient) {
    this.url = "http://localhost:9001/products";
  }

  getAllProducts() {
    return this.httpClient.get<Array<Product>>(this.url).pipe(
      retry(3),
      catchError(this._handleError<Array<Product>>('getAllProducts', []))
    )
  }

  getProduct(productId: number) {
    return this.httpClient.get<Product>(`${this.url}/${productId}`).pipe(
      retry(3),
      catchError(this._handleError<Product>('getProduct', undefined))
    )
  }

  createProduct(product: Product) {
    return this.httpClient.post<Product>(this.url, product).pipe(
      retry(3),
      catchError(this._handleError<Product>('createProduct', undefined))
    )
  }

  updateProduct(product: Product) {
    return this.httpClient.put<Product>(`${this.url}/${product.id}`, product).pipe(
      retry(3),
      catchError(this._handleError<Product>('updateProduct', undefined))
    )
  }

  deleteProduct(productId: number) {
    return this.httpClient.delete(`${this.url}/${productId}`).pipe(
      retry(3),
      catchError(this._handleError('deleteProduct', undefined))
    )
  }


  private _handleError<T>(operation = 'operation', result?: T) {
    return (err: HttpErrorResponse): Observable<T> => {
      console.log(`${operation} failed: ${err.message}`);
      return throwError(err.message);
    }
  }
}
