import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthenticatorService } from './authenticator.service';

@Injectable()
export class TokenInterceptorService implements HttpInterceptor {
  constructor(private authenticatorService: AuthenticatorService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (new RegExp('api/users').test(req.url)) {
      const authReq = req.clone({
        setHeaders: {
          'x-access-token': <string>this.authenticatorService.getToken()
        }
      });

      return next.handle(authReq);
    }
    return next.handle(req);
  }
}
