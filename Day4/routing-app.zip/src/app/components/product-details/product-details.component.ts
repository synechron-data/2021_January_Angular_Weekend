import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/models/product.model';
import { ProductService } from 'src/app/services/product.service';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs';

@Component({
  selector: 'product-details',
  template: `
    <div class="outerdiv">
      <div class="innerdiv">
          <h3 class="text-warning">Product Details</h3>
          <div *ngIf="product else elseBlock">
              <h3>{{product!.name}}</h3>
              <p>{{product!.description}}</p>
              <hr>
              <h4>{{product!.status}}</h4>
          </div>    
      </div>
    </div>
    <ng-template #elseBlock>
      <h3 class="text-danger">Product not Found..</h3>
    </ng-template>
  `,
  styles: [
  ]
})
export class ProductDetailsComponent implements OnInit, OnDestroy {
  product?: Product;
  rp_Sub?: Subscription;

  // ActivatedRoute, Provides access to information about a route associated with a component that is loaded in an outlet. 
  // Use to traverse the RouterState tree and extract information from nodes.

  // ActivatedRouteSnapshot
  // Contains the information about a route associated with a component loaded in an outlet at a particular moment in time. 
  // ActivatedRouteSnapshot can also be used to traverse the router state tree.

  // Since ActivatedRoute can be reused, ActivatedRouteSnapshot is an immutable object representing a particular version of ActivatedRoute. 
  // It exposes all the same properties as ActivatedRoute as plain values, while ActivatedRoute exposes them as observables.
  constructor(private productService: ProductService, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    // console.log(this.activatedRoute);
    this.rp_Sub = this.activatedRoute.params.pipe(map(param => param['id'])).subscribe(id => {
      this.product = this.productService.Products.find(p => p.id == id);
    });
  }

  ngOnDestroy(): void {
    this.rp_Sub?.unsubscribe();
  }
}
