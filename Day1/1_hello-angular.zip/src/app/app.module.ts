// import { BrowserModule } from '@angular/platform-browser';
// import { NgModule } from '@angular/core';
// import { HelloComponent } from './components/hello/hello.component';

// @NgModule({
//   declarations: [HelloComponent],
//   imports: [BrowserModule],
//   providers: [],
//   bootstrap: [HelloComponent]
// })
// export class AppModule { }

// ----------------------------------------------------

import { BrowserModule } from '@angular/platform-browser';
import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { HelloComponent } from './components/hello/hello.component';

@NgModule({
  declarations: [HelloComponent],
  imports: [BrowserModule],
  entryComponents: [HelloComponent]
})
export class AppModule implements DoBootstrap {
  ngDoBootstrap(appRef: ApplicationRef): void {
    const container = document.querySelector("#container");

    const helloTag = document.createElement('app-hello');
    helloTag.innerText = "Hello Tag Added Manually";
    container?.appendChild(helloTag);

    appRef.bootstrap(HelloComponent);
  }
}
